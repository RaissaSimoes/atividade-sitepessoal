<form id="frmLogin">
	Usuario:  <input type="text" name="usuario" ><br><br>
	Senha: <input type="password" name="senha"><br><br>
	<input type="button" id="Enviar" value="Enviar">
	<input type="reset" id="Apagar" value="Excluir">
	
</form>


<script type="text/javascript">
	$(document).ready(function() {
		$("#Enviar").click(function() {
			var url   = "section03.php";
			var dados = $("#frmLogin").serialize();
			$.post(url, dados, function(responseText) {
				var objResponse = JSON.parse(responseText);
				var outText = "Status da Autenticação: "+objResponse.login+"<br>"+"Dados:<br> "+objResponse.message;  
				$("#sct").html(outText);
				console.log(objResponse);
			} );
		});
	});
</script>