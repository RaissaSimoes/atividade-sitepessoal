<?php 

$usuario = $_REQUEST['usuario'];
$senha = $_REQUEST['senha'];

$logUsuario = "Raissa";
$logSenha = "naotemsenha";

$outArray = array();
if(isset($_REQUEST['usuario']) && isset($_REQUEST['senha'])){
    if (($usuario==$logUsuario)&&($senha==$logSenha)){
        $outArray = array( "login"=>"Logado", "message"=> "Nome: Raissa Simões dos Santos<br>Idade: 18<br>
Nascimento: 27/04/2003<br>Ensino: Estudante de Informática para Internet integrado ao Ensino Médio - 3ºAno<br>
Gostos: Gosto muito de escutar música, de dançar, de jogar vídeo-game e de assistir dramas e filmes asiáticos." );
    }else{
        $outArray = array("login"=>"Off", "message"=> "Usuário não Autenticado");
    }    
} else {
    $outArray = array("login"=>"Off", "message"=> "Informe Usuário e Senha");
}

echo json_encode($outArray, JSON_UNESCAPED_UNICODE);

?>