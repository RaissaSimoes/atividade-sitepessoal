<img src="img/eu.jpg" width=240 height=160><br>

<input type="button" id="login" value="Login">   

<script type="text/javascript">
	$(document).ready(function() {
		$("#login").click(function() {
			$("#sct").load("section02.php");
		});
	});
</script>